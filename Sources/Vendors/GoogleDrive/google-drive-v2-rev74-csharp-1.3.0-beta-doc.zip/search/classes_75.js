var searchData=
[
  ['untrashrequest',['UntrashRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1UntrashRequest.html',1,'Google::Apis::Drive::v2::FilesResource']]],
  ['updatemediaupload',['UpdateMediaUpload',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1UpdateMediaUpload.html',1,'Google::Apis::Drive::v2::FilesResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1CommentsResource_1_1UpdateRequest.html',1,'Google::Apis::Drive::v2::CommentsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1RevisionsResource_1_1UpdateRequest.html',1,'Google::Apis::Drive::v2::RevisionsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1RepliesResource_1_1UpdateRequest.html',1,'Google::Apis::Drive::v2::RepliesResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1UpdateRequest.html',1,'Google::Apis::Drive::v2::FilesResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1PermissionsResource_1_1UpdateRequest.html',1,'Google::Apis::Drive::v2::PermissionsResource']]],
  ['updaterequest',['UpdateRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1PropertiesResource_1_1UpdateRequest.html',1,'Google::Apis::Drive::v2::PropertiesResource']]],
  ['user',['User',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1Data_1_1User.html',1,'Google::Apis::Drive::v2::Data']]]
];
